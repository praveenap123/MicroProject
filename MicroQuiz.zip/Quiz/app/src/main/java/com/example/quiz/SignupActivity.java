package com.example.quiz;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {

    EditText fname,email,phone,password;
    Button btnsignup;
    TextView lredirect;
    SQLiteDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        this.getSupportActionBar().hide();
        fname=(EditText) findViewById(R.id.sfullname);
        email=(EditText) findViewById(R.id.semail);
        phone=(EditText) findViewById(R.id.sphone);
        password=(EditText) findViewById(R.id.spassword);
        btnsignup=(Button)findViewById(R.id.Btn_signup);
        lredirect=(TextView) findViewById(R.id.Glogin);
        mydb = openOrCreateDatabase("MyDb", Context.MODE_PRIVATE, null);
        if (mydb != null)
        {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        mydb.execSQL("CREATE TABLE IF NOT EXISTS tbllogin(fname VARCHAR,email VARCHAR,phone VARCHAR,password VARCHAR);");

        btnsignup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(fname.getText().toString().trim().length()==0||
                        email.getText().toString().trim().length()==0||
                        phone.getText().toString().trim().length()==0||
                        password.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please Fill all the fields");
                    return;
                }
                mydb.execSQL("INSERT INTO tbllogin VALUES('"+fname.getText()+"','"+email.getText()+
                        "','"+phone.getText()+"','"+password.getText()+"');");
                showMessage("Success", "Signup Successfull !");
                clearText();
                Intent in=new Intent(SignupActivity.this,LoginActivity.class);
                startActivity(in);



            }
        });
        lredirect.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent in=new Intent(SignupActivity.this,LoginActivity.class);
                startActivity(in);
            }
        });

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        fname.setText("");
        email.setText("");
        phone.setText("");
        password.setText("");
        fname.requestFocus();
    }
    }





